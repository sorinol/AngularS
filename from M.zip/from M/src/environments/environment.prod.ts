export const environment = {
  production: true,
  apiUrl: 'https://my-website.com:8080'
};

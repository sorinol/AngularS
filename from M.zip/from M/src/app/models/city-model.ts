

export interface CityModel {
  id: number;
  name: string;
  description: string;
  imageUrl: string;

}

export interface ClientModel {
  id: number;
  lastName: string;
  firstName: string;
  email: string;
  username: string;
  password: string;
  retypePassword: string;
}

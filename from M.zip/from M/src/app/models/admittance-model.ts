export  interface AdmittanceModel {
  id: number;
  name: string;
}

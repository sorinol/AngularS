export interface UserModel {
  id: number;
  lastName: string;
  firstName: string;
  email: string;
  password: string;
  retypePassword: string;
  role: string;
  phone: string;
  token: string;
}

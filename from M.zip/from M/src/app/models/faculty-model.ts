export interface CityModel {
  id: number;
  imageUrl: string;
  name: string;
  description: string;
  contactNumber: string;
  universityId: number;
}
